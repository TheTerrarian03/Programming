# MINDS-i
Code to assist with running MINDSi robots

This library contains code for running all the sensors sold with MINDSi kits, and examples for each chassis
